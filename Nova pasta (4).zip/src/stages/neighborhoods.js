export const neighborhoods =
  'Abraão Alab --> *5 reais* \
\nAdalberto Aragão --> *5 reais* \
\nAeroporto Velho --> *5 reais* \
\nAreial --> *6 reais* \
\nAviário --> *5 reais* \
\nAyrton Senna --> *7 reais*  \
\nBahia Nova --> *7 reais* \
\nBahia Velha --> *7 reais*  \
\nBairro XV --> *5 reais* \
\nBairro da Base --> *5 reais* \
\nBairro da Paz --> *5 reais* \
\nBoa União --> *7 reais* \
\nBosque --> *5 reais* \
\nCadeia Velha --> *5 reais* \
\nCaladinho --> *7 reais* \
\nCalafate --> *8 reais* \
\nCapoeira --> *5 reais* \
\nCentro --> *5 reais* \
\nCerâmica --> *5 reais* \
\nChico Mendes --> *5 reais* \
\nCidade Nova --> *5 reais* \
\nConjunto Adalberto Sena --> *5 reais* \
\nConjunto Bela Vista --> *5 reais* \
\nConjunto Castelo Branco --> *5 reais*  \
\nConjunto Esperança I e II --> *5 reais* \
\nConjunto Guiomard Santos --> *5 reais* \
\nConjunto Mariana --> *6 reais* \
\nConjunto Mascarenha de Morais --> *5 reais*  \
\nConjunto Rui Lino --> *6 reais* \
\nConjunto Tancredo Neves --> *5 reais* \
\nConjunto Tangará --> *5 reais* \
\nConjunto Tucumã I --> *7 reais* \
\nConjunto Tucumã II --> *7 reais* \
\nConjunto Xavier Maia --> *5 reais* \
\nConquista --> *5 reais* \
\nDefesa Civil --> *5 reais* \
\nDoca Furtado --> *5 reais* \
\nEldorado --> *5 reais* \
\nEstação Experimental --> *5 reais* \
\nFloresta --> *6 reais* \
\nFloresta Sul --> *8 reais* \
\nGeraldo Fleming --> *5 reais* \
\nHabitasa --> *6 reais* \
\nIpase --> *5 reais* \
\nIpê --> *8 reais*  \
\nIrineu Serra --> *7 reais*  \
\nIvete Vargas --> *5 reais*  \
\nIsaura Parente --> *5 reais* \
\nJardim Brasil --> *5 reais* \
\nJardim Europa --> *5 reais* \
\nJardim Primavera --> *6 reais* \
\nJoão Eduardo I --> *5 reais* \
\nJoão Eduardo II --> *5 reais*\
\nJorge Lavocat --> *5 reais* \
\nLoteamento Novo Horizonte --> *5 reais* \
\nManoel Julião --> *5 reais* \
\nMocinha Magalhães --> *7 reais* \
\nMontanhês --> *5 reais* \
\nMorada do Sol --> *5 reais* \
\nNova Estação --> *5 reais* \
\nPalheiral --> *6 reais* \
\nPapouco --> *5 reais* \
\nParque dos Sabiás --> *5 reais* \
\nPista --> *5 reais* \
\nPlacas --> *5 reais* \
\nPortal da Amazônia Placas --> *8 reais* \
\nRaimundo Melo --> *5 reais* \
\nResidencial Ouricuri --> *5 reais* \
\nSanta Inês --> *8 reais* \
\nSão Francisco --> *5 reais* \
\nSeis de Agosto --> *5 reais* \
\nSobral --> *5 reais* \
\nTropical --> *5 reais* \
\nVila Ivonete --> *5 reais* \
\nVila Nova --> *5 reais* \
\nVillage --> *5 reais* \
\nVitória --> *5 reais*  \
\nVolta Seca --> *5 reais* \
\nWanderley Dantas --> *5 reais*';
