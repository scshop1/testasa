import { initialStage } from './0.js';
import { stageOne } from './1.js';
import { stageTwo } from './2.js';
import { stageThree } from './3.js';
import { stageFour } from './4.js';
import { finalStage } from './5.js';

export { initialStage, stageOne, stageTwo, stageThree, stageFour, finalStage };
