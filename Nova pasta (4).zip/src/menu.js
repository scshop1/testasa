export const menu = {
  1: {
    description: ' AL Ain Milk',
    price: 6,
  },
  2: {
    description: 'Apple',
    price: 6,
  },
  3: {
    description: 'Sugar',
    price: 6,
  },
  4: {
    description: 'Onion',
    price: 6,
  },
  5: {
    description: 'Tomato',
    price: 6,
  },
};
